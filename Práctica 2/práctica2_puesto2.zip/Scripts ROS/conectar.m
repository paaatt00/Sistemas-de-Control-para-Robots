clc; clear all; close all;

rosinit('http://192.168.0.41:11311', 'NodeHost', '192.168.0.12');