clc; clear all; close all;

rosinit('http://172.29.30.177:11311', 'NodeHost', '172.29.29.59');